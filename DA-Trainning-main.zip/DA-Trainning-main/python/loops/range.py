for i in range(1,11,2):
    print(i)