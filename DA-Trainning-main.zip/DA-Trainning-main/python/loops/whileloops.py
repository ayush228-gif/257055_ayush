i=7
while i<8:
    print(i)
    i=i+1
    