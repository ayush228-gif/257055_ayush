x="Good"
def myfunc():
    print("Python is",x)
myfunc()



def abc(name):
    print(f"Hello {name}")   
abc("Aman")