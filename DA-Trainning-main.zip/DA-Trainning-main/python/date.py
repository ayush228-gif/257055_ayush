import datetime
today = datetime.date.today()
print("today's date:",today)
now = datetime.datetime.now()
print("now:",now)