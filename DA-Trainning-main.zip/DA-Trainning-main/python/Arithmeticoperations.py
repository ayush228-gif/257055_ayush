a=12
b=34
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)