print("Enter your age : ")
age = int(input())
if age>=18:
    print("You are eligible to vote")
else:
    print("You are not eligible to vote")
    