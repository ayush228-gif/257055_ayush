print("Enter ur grade : ")
grade = int(input())
if grade>=35 and grade<65:
    print("Ur grade is C")
elif grade>=65 and grade<80:
    print("Ur grade is B")
elif grade>=80 and grade<=95:
    print("Ur grade is A")
elif grade>95:
        print("Ur grade is A+")
else:
    print("U r fail")