import person
person.greet("Aman")
