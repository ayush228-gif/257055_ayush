import sys
print("Python version:", sys.version)
print("platform:",sys.platform)
