import pandas as pd

data=[10,20,30,40]
s=pd.Series(data)

print(s)