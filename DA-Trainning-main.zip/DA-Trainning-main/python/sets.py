#sets are used to store multiple items in a single variable
a={"Aman","Amit","Ayush"}  
print(len(a))  #length of set
print(a)        #accessing items
print(type(a))  #type of variable
a.add("Ankit")  #adding item to set
print(a)