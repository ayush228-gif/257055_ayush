#list are used to store multiple items in a single variable
a=["Aman","Amit","Ayush"]
print(len(a))  #length of list
print(a[0])    #accessing first item
print(type(a))  #type of variable