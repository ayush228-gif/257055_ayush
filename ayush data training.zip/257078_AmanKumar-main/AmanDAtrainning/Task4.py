print("Enter Any Number :")
num=int(input())
if num>0:
    print("Number is Positive")
else:
    print("Number is negative")    
if num%5==0:
    print("Number is divisible by 5")
else:
    print("Number is not divisible by 5")
if num%2==0:
    print("Number is even")
else:
    print("Number is odd")            
