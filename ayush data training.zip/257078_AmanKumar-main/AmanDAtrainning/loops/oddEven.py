count=5
while count>0:
    if count%2==0:
        print(f"{count} is Even")
    else:
        print(f"{count} is Odd")
    count-=1