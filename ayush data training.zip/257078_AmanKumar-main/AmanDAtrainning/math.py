import math 
print("Power of 25 6",pow(25,6))
print("Square root of 16:",math.sqrt(16))
print("value of pi",math.pi)
print("ceil of 4.3",math.ceil(4.3))
print("Floor of 4.8",math.floor(4.8))
# 
# import math
# print("power of 2 4 :",pow(2,4))
# print("square root of 225:",math.sqrt(225))
# print("value of pi",math.pi)      
#   