
def greet(name):
    
    print("My name is",name)
   