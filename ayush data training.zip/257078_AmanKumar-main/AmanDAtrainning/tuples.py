#tuples are used to store multiple items in a single variable
a=("Aman","Amit","Ayush")
print(len(a))  #length of tuple
print(a[1])    #accessing first item
print(type(a))  #type of variable
