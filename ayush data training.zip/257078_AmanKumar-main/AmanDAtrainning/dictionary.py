#dictionary are used to store data values in key:value pairs
a={"name":"Aman","age":20,"city":"Raniganj"}
print(len(a))          #length of dictionary
print(a["name"])      #accessing items
print(type(a))        #type of variable