import pandas as pd
data= {
    'Name': ['Aman','ritik','Ayush','Shivam'],
    'Age': [21,22,19,20],
    'Marks': [85,90,78,92]
}
df=pd.DataFrame(data)
print(df)
# print(pd.__version__)