def square(num):
    return num*num
result= square(50)
print("square is",result)