class abc:
 def __init__(self, name, age):
     self.name= name
     self.age= age
p1=abc("AMAN",19)
print(p1.name)  
print(p1.age)  