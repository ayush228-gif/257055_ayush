class Cat:
    def sound(self):
        return "Meow😹"
class Dog:
    def sound(self):
        return "Bark🐶"
p1=Dog()
p2=Cat()
print(p1.sound())
print(p2.sound())