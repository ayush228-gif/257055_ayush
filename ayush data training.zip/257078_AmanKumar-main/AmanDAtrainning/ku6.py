def number(num1,num2):
    return num1+num2
result= number(5,10)
print("Sum is",result)
