import random
print("Random numbers between 1-10:",random.randint(1, 10))
colors= ["red","orange","green","white"]
print("random color:",random.choice(colors))