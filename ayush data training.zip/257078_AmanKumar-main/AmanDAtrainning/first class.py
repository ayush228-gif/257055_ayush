x="Aman"
print(x)
